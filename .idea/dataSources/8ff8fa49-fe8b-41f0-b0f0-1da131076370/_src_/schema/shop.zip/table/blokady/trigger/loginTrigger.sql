CREATE TRIGGER `loginTrigger`
BEFORE INSERT ON `blokady`
FOR EACH ROW
  begin
if(lower(NEW.login)<>NEW.login) then
set NEW.login=lower(login);
end if;

end