CREATE TRIGGER `ArchiwumUzytkownicy_Login_Update`
BEFORE UPDATE ON `uzytkownicy`
FOR EACH ROW
  begin
if(lower(NEW.login)<>NEW.login) then
set NEW.login=lower(login);
end if;

end