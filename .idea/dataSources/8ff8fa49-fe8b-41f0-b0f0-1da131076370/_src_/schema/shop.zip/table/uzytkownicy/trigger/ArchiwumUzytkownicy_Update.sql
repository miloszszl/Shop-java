CREATE TRIGGER `ArchiwumUzytkownicy_Update`
AFTER UPDATE ON `uzytkownicy`
FOR EACH ROW
  insert into
ArchiwumUzytkownicy(idUzytkownika,imie,nazwisko,login,haslo,mail,idMiasta,nazwaUlicy,numerDomu,idTypuKonta,akcja) 
values
(old.idUzytkownika,old.imie,old.nazwisko,old.login,old.haslo,old.mail,old.idMiasta,old.nazwaUlicy,
old.numerDomu,old.idTypuKonta,'u')