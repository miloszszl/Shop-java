CREATE FUNCTION `insert_grade`(`u_id` INT(10) UNSIGNED, `rate_val` DECIMAL(3, 1), `product_id` INT(10) UNSIGNED)
  RETURNS INT(1)
BEGIN
	DECLARE EXIT HANDLER FOR SQLSTATE '12345'
		return 0;

	IF(rate_val<1 OR rate_val>10) THEN
		SIGNAL SQLSTATE '12345' SET MESSAGE_TEXT = 'An error occurred';
	ELSE
		INSERT INTO Oceny (idProduktu,idUzytkownika,wartosc) 
		VALUES (product_id,u_id,rate_val);
		return 1;
	END IF;

END