CREATE PROCEDURE `change_pass`(IN `idUser` INT(10) UNSIGNED, IN `newPass` VARCHAR(42))
  BEGIN
	UPDATE Uzytkownicy SET haslo=newPass
	WHERE idUzytkownika=idUser;

END