CREATE VIEW `v_order_info` AS
  SELECT
    `z`.`idZamowienia`                                               AS `Id_zamowienia`,
    concat(`m`.`nazwa`, ' ', `u`.`nazwaUlicy`, ' ', `u`.`numerDomu`) AS `Adres`,
    `u`.`login`                                                      AS `Login`,
    `z`.`dataZamowienia`                                             AS `Data_zamowienia`,
    `d`.`nazwa`                                                      AS `Nazwa_dostawcy`,
    `d`.`cena`                                                       AS `Cena_dostawcy`,
    `sz`.`nazwaStatusuZamowienia`                                    AS `Status_zamowienia`,
    (sum((`p`.`cena` * `pz`.`ilosc`)) + `d`.`cena`)                  AS `Kosz_całkowity`
  FROM ((((((`shop`.`uzytkownicy` `u`
    JOIN `shop`.`miasta` `m` ON ((`m`.`idMiasta` = `u`.`idMiasta`))) JOIN `shop`.`zamowienia` `z`
      ON ((`z`.`idUzytkownika` = `u`.`idUzytkownika`))) JOIN `shop`.`dostawcy` `d`
      ON ((`d`.`idDostawcy` = `z`.`idDostawcy`))) JOIN `shop`.`statusyzamowien` `sz`
      ON ((`sz`.`idStatusuZamowienia` = `z`.`idStatusuZamowienia`))) JOIN `shop`.`produktyzamowienia` `pz`
      ON ((`pz`.`idZamowienia` = `z`.`idZamowienia`))) JOIN `shop`.`produkty` `p`
      ON ((`p`.`idProduktu` = `pz`.`idProduktu`)))
  WHERE (`z`.`dataZamowienia` IS NOT NULL)
  GROUP BY `z`.`idZamowienia`, concat(`m`.`nazwa`, ' ', `u`.`nazwaUlicy`, ' ', `u`.`numerDomu`), `u`.`login`,
    `z`.`dataZamowienia`, `d`.`nazwa`, `d`.`cena`, `sz`.`nazwaStatusuZamowienia`