CREATE VIEW `front_page_view` AS
  SELECT
    `shop`.`zdjecia`.`link`        AS `link`,
    `shop`.`produkty`.`nazwa`      AS `nazwa`,
    `shop`.`produkty`.`idProduktu` AS `idProduktu`,
    `shop`.`produkty`.`ilosc`      AS `ilosc`,
    `shop`.`produkty`.`cena`       AS `cena`
  FROM (`shop`.`produkty`
    LEFT JOIN `shop`.`zdjecia` ON ((`shop`.`zdjecia`.`idProduktu` = `shop`.`produkty`.`idProduktu`)))
  WHERE (`shop`.`produkty`.`ilosc` > 0)
  ORDER BY rand()
  LIMIT 6