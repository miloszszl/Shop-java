CREATE FUNCTION `update_grade`(`u_id` INT(10) UNSIGNED, `rate_val` DECIMAL(3, 1), `product_id` INT(10) UNSIGNED)
  RETURNS INT(1)
BEGIN
	DECLARE EXIT HANDLER FOR SQLSTATE '12345'
		return 0;

	IF(rate_val<1 OR rate_val>10) THEN
		SIGNAL SQLSTATE '12345' SET MESSAGE_TEXT = 'An error occurred';
	ELSE
		UPDATE Oceny SET wartosc=rate_val 
		WHERE idProduktu=product_id AND idUzytkownika=u_id;
		return 1;
	END IF;

END