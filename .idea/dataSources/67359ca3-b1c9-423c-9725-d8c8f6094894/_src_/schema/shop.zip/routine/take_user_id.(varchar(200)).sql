CREATE PROCEDURE `take_user_id`(IN `ids` VARCHAR(200))
  BEGIN
SELECT idUzytkownika FROM Sesja WHERE id=ids;

END