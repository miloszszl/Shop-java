CREATE PROCEDURE `insert_delivery`(IN `nazwa_d` VARCHAR(50), IN `cena_d` DECIMAL(5, 2))
  BEGIN
	declare exit handler for sqlstate '23000'
begin
	signal sqlstate '45000' set message_text="Taki dostawca już istnieje !", mysql_errno='1001';
end;

INSERT INTO Dostawcy (nazwa, cena) VALUES (nazwa_d,cena_d);

END