CREATE TRIGGER `del_zam`
AFTER DELETE ON `produktyzamowienia`
FOR EACH ROW
  BEGIN
  DECLARE x INT;
	SET x=(SELECT count(*) FROM ProduktyZamowienia pz  WHERE pz.idZamowienia=old.idZamowienia);
  
	if(x=0) THEN
		DELETE FROM Zamowienia WHERE idZamowienia=old.idZamowienia;
	END IF;
END