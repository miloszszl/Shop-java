CREATE VIEW `v_user_info` AS
  SELECT
    `u`.`idUzytkownika` AS `idUzytkownika`,
    `u`.`imie`          AS `imie`,
    `u`.`nazwisko`      AS `nazwisko`,
    `u`.`login`         AS `login`,
    `u`.`haslo`         AS `haslo`,
    `u`.`mail`          AS `mail`,
    `u`.`telefon`       AS `telefon`,
    `m`.`nazwa`         AS `miasto`,
    `u`.`nazwaUlicy`    AS `nazwaUlicy`,
    `u`.`numerDomu`     AS `numerDomu`,
    `tk`.`typKonta`     AS `typKonta`
  FROM ((`shop`.`uzytkownicy` `u`
    JOIN `shop`.`miasta` `m` ON ((`m`.`idMiasta` = `u`.`idMiasta`))) JOIN `shop`.`typykont` `tk`
      ON ((`tk`.`idTypuKonta` = `u`.`idTypuKonta`)))