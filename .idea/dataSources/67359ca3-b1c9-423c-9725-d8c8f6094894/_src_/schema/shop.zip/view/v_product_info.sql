CREATE VIEW `v_product_info` AS
  SELECT
    `p`.`nazwa` AS `Nazwa_produktu`,
    `p`.`ilosc` AS `Ilość`,
    `p`.`cena`  AS `Cena_produktu`,
    `p`.`ocena` AS `Średnia_ocen`,
    `p`.`opis`  AS `Opis`,
    `m`.`nazwa` AS `Marka`,
    `k`.`nazwa` AS `Kategoria`
  FROM ((`shop`.`produkty` `p`
    JOIN `shop`.`marki` `m` ON ((`p`.`idMarki` = `m`.`idMarki`))) JOIN `shop`.`kategorie` `k`
      ON ((`k`.`idKategorii` = `p`.`idKategorii`)))